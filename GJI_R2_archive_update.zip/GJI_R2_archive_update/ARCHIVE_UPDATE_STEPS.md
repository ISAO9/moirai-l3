# アーカイブ更新手順（GJI-26-0613 第2回改訂）

本文の Data Availability が「This round adds **scripts 15-25 and their outputs**」と
書いた以上、投稿前にアーカイブ側を実際に更新する必要がある。以下はそのための手順。

**実行は本人が行う。** このバンドル内のファイルをコピーして、記載のコマンドを
自分の作業コピーで走らせること。

---

## 0. 先に確認した事実（根拠つき）

### DOI — 本文の 21217614 が concept DOI。README の 21217615 は誤記ではなく v0.1.0 の版 DOI

**訂正。** 私は当初 README の `21217615` を「1 違いの誤記」と書いたが、**これは誤り**だった。
過去のチャット（2026-07-06）を調べたところ、当時の原稿と README はどちらも
`doi:10.5281/zenodo.21217615` と書いていた。つまり 21217615 は実際に発行された DOI である。

Zenodo は concept DOI と最初の版 DOI を隣り合う番号で発行し、**concept が 1 小さい**。
他プロジェクトでも同じ規則が成り立っている:

| プロジェクト | 最初の版 DOI | concept DOI |
|---|---|---|
| DRYAS | 22349502 (v1.0.0) | 22349501 |
| THEIA/HELIOS-N | 21397829 (v1.0.0) | 21397828 |
| **MOIRAI L3** | **21217615 (v0.1.0)** | **21217614** |

| 確認したこと | 結果 |
|---|---|
| `https://doi.org/10.5281/zenodo.21217614` | 302 → `https://zenodo.org/records/22224441` |
| その record | **version v0.2.0**、published **2026-09-01**、version DOI `10.5281/zenodo.22224441` |

よって:

- **21217614 = concept DOI**（常に最新版へ飛ぶ）→ 本文の記述「which always resolves to
  the latest version」は正しい。**本文は直さない。**
- **21217615 = v0.1.0 の版 DOI** → 間違いではないが、v0.2.0 が出た時点で古くなっている
  （最新版ではなく v0.1.0 を指す）。README は concept DOI に差し替えるのが正しい。

バンドルの README には、concept と各版 DOI の対応を併記した。

> **教訓（過去に同じ失敗がある）。** THEIA/HELIOS-N では版 DOI を論文に書いてしまい、
> Zenodo サポートに依頼を出す事態になった。MOIRAI の本文は既に concept DOI なので
> 問題ない。README だけが v0.1.0 当時のまま残っていた。

### プレプリント DOI が「to be assigned」のまま残っていた

EarthArXiv のプレプリントは **2026-07-15 に公開済み**（本人の報告: doi:10.31223/X5121S）。
ところが公開中のアーカイブは 3 箇所が未記入のままだった:

| 場所 | 公開中 | バンドルで |
|---|---|---|
| `README.md` | `Preprint: EarthArXiv, **DOI: _to be assigned_**` | `doi:10.31223/X5121S` |
| `CITATION.cff` の `notes` | `"Preprint: EarthArXiv, DOI to be assigned."` | 実 DOI |
| `.zenodo.json` の `related_identifiers` | AMBER のみ | `isSupplementTo: 10.31223/X5121S` を追加 |

### 学習済み重みがどこにも公開されていなかった

**これが今回いちばん重い発見。** 原稿はこう書いている。

> The training, evaluation and analysis code, **the EMA-best model weights**, and the
> scripts that regenerate every figure and table are released in a public archive.

実態（実測と本人確認）:

| 場所 | 重み |
|---|---|
| git 本体 | `.gitignore` で除外（意図通り） |
| GitHub Release 添付 | **無し**（本人確認） |
| Zenodo v0.2.0 record（concept DOI の現在の行き先） | **無し**。添付は `ISAO9/moirai-l3-v0.2.0.zip` 3.3 MB 1 本のみ |
| `model/README.md` の記述 | 「Zenodo archive and/or GitHub Release にある」と書いてある |

2026-07-06 のチャットで、EMA-best を 44 本（LOSO 16 + seed 24 + shuffle 4）集めて
Release に添付する計画を立て、Drive から集めて合計サイズを報告する Colab セルまで
用意していた。しかし**そのサイズ報告も、アップロード完了の確認も、以降のチャットに
出てこない。** Release 説明文の "Weights (EMA-best) attached as release assets" は、
添付前に書いたテンプレート文だった。

**方針（本人判断 2026-10-08）: 重みを公開する。** 原稿の記述をそのまま真にする。
論文がピッカーそのものを扱う以上、重み公開は弱点ではなく強みになる。

#### なぜ Zenodo に直接上げるのか

GitHub↔Zenodo 連携は **Release の publish で発火し、リポジトリのソースだけ**を
Zenodo に送る。v0.2.0 の record が 3.3 MB 1 本であることがその実測証拠。
Release にバイナリを添付しても Zenodo の record には入らない。
よって重みは **Zenodo 側で直接**載せる（`MOIRAI_L3_zenodo_weights.ipynb`）。

#### 順序が決定的に重要

```
  ① push + tag v0.3.0            （MOIRAI_L3_archive_push.ipynb）
  ② GitHub Release は作らない     ★ ここが肝
  ③ Zenodo で新しい版の下書き     （MOIRAI_L3_zenodo_weights.ipynb）
       v0.3.0 のソース zip + 重み 44 本
  ④ ブラウザで中身を確認して Publish
```

②で Release を publish してしまうと連携が発火し、**重みの無いソースだけの版**が
最新になる。concept DOI 21217614 はそこを指すので、原稿の主張が成り立たなくなる。
push ノートの Cell 7 はこれを明示して止まる作りにした。

> タグ v0.3.0 は GitHub に載るのでコードの版は辿れる。原稿は GitHub を
> mirror として URL で参照しているだけなので、Release ページが無くても
> 主張には影響しない。

#### Zenodo 側で確認した仕様（推測ではない）

| 確認したこと | 出典 |
|---|---|
| record ページの **New version** で前版のファイルを Import し、追加・削除・変更できる | Zenodo help「Manage versions」 |
| 公開済み record のファイルは変更不可。ファイルを増やすには新しい版が必要 | 同 |
| API: `POST /api/deposit/depositions/{id}/actions/newversion` | 実在スクリプト |
| API: `PUT {links.bucket}/{filename}` でファイル転送（大容量可） | Zenodo 開発者の gist |
| トークンの scope は `deposit:write` と `deposit:actions` | 同 |

#### Publish は自動化しない

Zenodo の版は**公開すると消せない**（THEIA では不要な版の処理で Zenodo サポートに
依頼を出す事態になった）。だから `MOIRAI_L3_zenodo_weights.ipynb` は**下書きを作って
中身を揃えたところで止まる**。本人が URL を開いて確認してから Publish を押す。
下書きのうちは Discard すれば何も公開されない。

### 残る未処理: プレプリント PDF 内のプレースホルダ（本人判断）

`paper/MOIRAI_L3_preprint.pdf`（公開中）の 1 ページ目に、未置換のまま 3 箇所残っている:

```
PreprintDOI: [EarthArXiv DOI: to be assigned on posting]
Code&dataarchive: ZenodoDOI [10.5281/zenodo.XXXXXXX: to be assigned] |
https://github.com/<user>/moirai-l3
```

**今回は触らない。** 理由は 2 つ。

1. この PDF は **Author's Original Version** であり（1 ページ目に明記）、GJI の規定
   「査読中に公開してよいのは AOV のみ」を満たしている。差し替えると、EarthArXiv に
   載っている実物とアーカイブの中身が食い違う。
2. 再ビルドには LaTeX ソースが必要だが、アーカイブには PDF と図しか入っていない。

直すなら EarthArXiv 側の版も同時に差し替える必要があり、それは別作業。
バンドルの README・CITATION.cff・.zenodo.json が実 DOI を持つので、
アーカイブを開いた読者が DOI に到達できない状態ではない。

### 過去の公開手順（参考）

- **v0.1.0（2026-07）**: Mac の `~/moirai-l3` で `brew install gh` → `gh auth login`
  （ブラウザ認証）→ `gh repo create moirai-l3 --public --source=. --remote=origin --push`。
  つまり **PAT は使わず gh CLI のブラウザ認証**だった。
- **Zenodo**: `zenodo.org/account/settings/github/` で `moirai-l3` を ON にしてある。
  以後 **GitHub の Release を publish すると Zenodo が自動で新版を作る**。
  この連携は一度入れれば有効なので、今回も Release を作るだけでよい。

> その Mac にまだ `gh` の認証が残っていれば、PAT を作らずに済む。
> `gh auth status` で確認できる。

### 公開中のアーカイブの script 14 は R1-5 前の版

これは**見つかった不具合**で、修正が必要。

```
23_fig4_style_supplement.py  FAIL: AssertionError: script 14 is not the patched version (R1-5)
```

公開中（v0.2.0）の `src/14_fig4_and_tableS1.py` は 525 行、本バンドルの修正版は 740 行。
両方に `_pick_event` はあるが、**イベント選択ロジックが別物**である。実測した差:

| | 公開版 (v0.2.0) | バンドル版 |
|---|---|---|
| `selection_stage` の出現 | 0 件 | 3 件 |
| 追加関数 | — | `consistent_draw`, `pick_panel` |
| script 23 の `assert order[0] == 1` | **失敗** | 通る |

script 23 の selftest は 207–208 行で、`_pick_event` が返す並び順と、返り値の
`info` に `selection_stage` キーがあることを assert している。公開版のツリーに
script 23 を置いて実行して、失敗を再現済み:

```
File ".../src/23_fig4_style_supplement.py", line 207, in selftest
    assert order[0] == 1, "script 14 is not the patched version (R1-5)"
AssertionError: script 14 is not the patched version (R1-5)
```

**置き換えが必須**。置き換えないと、アーカイブを落とした読者の手元で 23 が動かない。

### 検査結果（バンドル適用後のツリーで実測）

公開中の v0.2.0 を展開し、本バンドルを被せたツリーで全スクリプトの `--selftest` を実行:

```
14_fig4_and_tableS1.py             PASS      ← 置き換えで解消
15_phase_confusion.py              PASS
16_arrival_audit.py                PASS
17_geometry_and_distance.py        PASS
18_paired_cache.py                 PASS
19_capacity_and_overfitting.py     PASS
20_within_array.py                 PASS
21_event_accounting.py             PASS
22_sampling_rates.py               PASS
23_fig4_style_supplement.py        PASS      ← 置き換えで解消
24_moveout_ratio_check.py          PASS
25_build_supplement.py             PASS
10-13                              PASS
00                                 selftest 無し（設定ファイル）
01-07, 09                          この環境では torch / h5py が無く未実行（内容は無変更）
```

---

## 1. バンドルの中身

```
ARCHIVE_UPDATE_STEPS.md         このファイル
MOIRAI_L3_archive_push.ipynb    Colab: clone → push → tag（経路 A、Cell 1-7）
MOIRAI_L3_zenodo_weights.ipynb  Colab: 重みを Zenodo の新しい版に載せる（Cell 1-7）
MOIRAI_L3_archive_update.ipynb  Colab: payload.zip を作る（経路 B、Cell 1-8）
model_README.md                 model/README.md として置く（重みの所在を Zenodo に明記）
README.md                    差し替え（DOI 修正、00-25 の一覧、題名更新）
REVISION_NOTES.md            差し替え（第2回の 15-25 を追記）
CITATION.cff                 差し替え（version 0.3.0、<user> と XXXXXXX を実値に）
.zenodo.json                 差し替え（題名・keywords・description）
pyproject.toml               差し替え（description と version のみ）
.gitignore                   差し替え（logs/15-25 と PDF/15-25 を追跡対象に）
src/00_config_l3.py          置き換え（モジュール docstring 1 文のみ）
src/14_fig4_and_tableS1.py   置き換え（R1-5 修正版）
src/15_*.py … src/25_*.py    新規 11 本
src/figures/                 新規 4 ファイル（script 25 が埋め込む図の素材）
```

### "velocity-free" の扱い

原稿本文から "velocity-free" は **0 件**になった（第1回改訂で査読者が曖昧だと
指摘したため）。公開中のアーカイブにはまだ 5 箇所残っていたので、全部そろえた:

| 場所 | 対応 |
|---|---|
| `README.md` 題名 | 削除 |
| `CITATION.cff` title / keywords | "array moveout" に差し替え |
| `.zenodo.json` title / keywords | 同じ |
| `pyproject.toml` の `description` | 同じ（`version` も 0.1.0 → 0.3.0） |
| `src/00_config_l3.py` の docstring | 原稿と同じ言い方 "needs no velocity model" に書き換え |

`00_config_l3.py` の変更は **docstring 1 文だけ**。モジュール docstring を除いた
AST が変更前と完全一致することを機械で確認した（コードは 1 文字も動いていない）。
概念自体は原稿も保持している（Summary: "A waveform-direct picker that needs no
velocity model"）ので、語の置き換えだけで意味は変わらない。

> **ここは本人判断で戻せる。** Zenodo record の題名を v0.1.0 / v0.2.0 と揃えて
> おきたいなら、`CITATION.cff` と `.zenodo.json` の `title` を元に戻すだけでよい。
> 他のファイルには影響しない。

---

## 2. 経路は2つ。どちらでもよい

Mac にクローンが無い状態なので、**経路 A（Colab だけで完結）** を既定とする。
Mac の `gh` 認証が残っているなら **経路 B** の方が手数は少ない。

### 経路 A — Colab だけで完結（`MOIRAI_L3_archive_push.ipynb`）

ログが Drive にあるので、ファイルの持ち運びが一度も発生しない。
Colab 内で clone して commit・push・タグまで済ませる。
GitHub への認証は fine-grained PAT（ノートの Cell 6 が `getpass` で受け取る）。

```
  [Colab]  clone → zip を upload → src 配置 → Drive から logs/PDF
             → 検査（selftest 全数・90/90） → commit → push → tag v0.3.0
  [Web]    GitHub で Release を publish → Zenodo が自動で新版
```

### 経路 B — Mac に clone し直す（`gh` 認証が残っている場合）

v0.1.0 のときは `gh auth login` のブラウザ認証で push しており、PAT を作っていない。
その認証が生きていれば、トークンの発行が不要になる。

```bash
gh auth status            # 認証が残っているか確認
cd ~/Documents            # 置きたい場所
git clone https://github.com/ISAO9/moirai-l3.git
cd moirai-l3
```

このあとは、Colab の `MOIRAI_L3_archive_update.ipynb`（Cell 1–8）で
`GJI_R2_archive_payload.zip` を作って Mac に落とし、下の手順 4 以降に進む。

```
  [Colab]  検査（selftest 全数・90/90）→ payload.zip を download
                                   │
  [Mac]    リポジトリ直下で unzip ─┘ → git add / commit / push → tag → Release
```

> どちらの経路でも、git に入る内容は同じ 78 ファイル（新規 70 / 変更 8）。
> 実クローンで両方試して一致を確認済み。

## 3. Colab 側（`MOIRAI_L3_archive_update.ipynb`）

ノートを Colab で開き、**Cell 1 → 2 → 3 → 4 → 5 → 6 → 7 → 8 を上から順に全部**実行する。

| Cell | 何をするか | 見るところ |
|---|---|---|
| 1 | Drive をマウントして `MyDrive/MOIRAI_L3` へ移動 | 更新前の `src/` と `logs/` の中身 |
| 2 | `GJI_R2_archive_update.zip` を upload して展開 | **zip をそのまま選ぶ。** 25 だけではなく 00 と 14 も置き換わる |
| 3 | `reportlab` と `pypdf` を入れる | — |
| 4 | 10–25 の全 selftest | 全部 PASS。**23 が通ること**が今回の要点 |
| 5 | `25 --inventory`（ファイルは書かない） | `missing` が空であること |
| 6 | `25 --build` で補遺を組み立て | — |
| 7 | 数値検査の結果 | **`numbers : {'total': 90, 'failed': 0}`** |
| 8 | git に入れる一式を zip にして download | ファイル一覧。`selftest` が 1 つも無いこと |

### 補足

- **Cell 2 は上書きする。** 上書き前の `src/*.py` は `src/_backup_<日時>/` に退避するので、
  何かあれば戻せる。退避フォルダは git には入らない（`src/` 直下の `*.py` だけを拾う）。
- **Cell 4 と Cell 7 は assert で止まる。** FAIL や failed>0 のまま先へ進めない作りにした。
  止まったら、そこが原稿か補遺の誤りなので先に直す。
- **Cell 8 の zip に入るもの**（`selftest` 産物は除外）:

  | 種類 | 対象 |
  |---|---|
  | ドキュメント | README.md / REVISION_NOTES.md / CITATION.cff / .zenodo.json / pyproject.toml / .gitignore |
  | スクリプト | src/00、src/14（置き換え）、src/15–25（新規）、src/figures/ 4 ファイル |
  | ログ | logs/15–25 の json・md・csv、logs/supplement/ |
  | 図 | PDF/15–25 の pdf・png |

> Colab を使わず Mac だけで済ませたい場合は、Drive の `logs/` と `PDF/` から
> 15–25 の json・md・csv・pdf・png（`selftest` を除く）を手でコピーし、
> バンドルの中身をリポジトリに `cp` してから手順 5 の検査を回す。
> やることは同じで、Colab 版はそれを取りこぼしなく自動でやるだけ。

---

## 4. Mac 側（経路 B）— 展開する

`GJI_R2_archive_payload.zip` が落ちてきたら、**リポジトリ直下**で展開する。
zip の中はリポジトリと同じ構造（`README.md`, `src/...`, `logs/...`, `PDF/...`）なので、
展開するだけで正しい場所に入る。

```bash
cd ~/path/to/moirai-l3

# 展開前に、いま何が変わるかを見る（上書きされるファイルの一覧）
unzip -l ~/Downloads/GJI_R2_archive_payload.zip

git status --short            # 作業ツリーが汚れていないことを確認
unzip -o ~/Downloads/GJI_R2_archive_payload.zip -d .
```

## 5. Mac 側（経路 B）— 検査する

```bash
# 00 の変更が docstring だけであること（コード部分が動いていないこと）
git diff src/00_config_l3.py

# 14 が置き換わったこと
git diff --stat src/14_fig4_and_tableS1.py

# 追加・変更されるファイルの一覧。selftest 産物が無いことを目で確認する
git add -A && git status --short
git status --short | grep -i selftest && echo "!!! selftest が混入している" || echo "selftest の混入なし"
```

`.gitignore` は実ファイル名で `git check-ignore` にかけて検証済み。
15–25 の本番ログと PDF は追跡対象、`*selftest*` は除外、`src/figures/` は追跡対象になる。

## 6. コミットして push（経路 B。経路 A はノートの Cell 5–7 が同じことをする）

```bash
git add -A
git status            # 追加されるファイルを目で確認する（selftest 産物が無いこと）
git commit -m "Add second-round revision analyses 15-25 (GJI-26-0613)

- scripts 15-25: phase confusion, arrival audit, geometry and source-receiver
  distance, identical-input evaluation, capacity, within-array experiment,
  event accounting, sampling rates, supplementary diagnosis panels, moveout
  distributions, Supporting Information assembly
- replace script 14 with the R1-5 patched version (script 23 asserts it)
- add src/figures/: published figure assets the supplement builder embeds
- README: correct the Zenodo DOI to the concept DOI 10.5281/zenodo.21217614
  (was 10.5281/zenodo.21217615), document scripts 10-25
- CITATION.cff / .zenodo.json / pyproject.toml: fill the repository and DOI
  placeholders, bump to 0.3.0, drop 'velocity-free' (the term no longer appears
  in the manuscript) and adopt the shortened paper title
- 00_config_l3.py: docstring only, same change of wording (AST unchanged)
- .gitignore: track the 15-25 logs and figures, never the selftest artefacts

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01DCHfYX3eUgM2Cmn1mqzV7V"

git push origin main
```

## 7. Zenodo に新しい版を出す（`MOIRAI_L3_zenodo_weights.ipynb`）

**GitHub の Release は作らない。** 理由は 0 節の「順序が決定的に重要」のとおり。
重みは Zenodo 側に直接載せる。

ノートを Colab で開き、**Cell 1 → 2 → 3 → 4 → 5 → 6 → 7** を上から順に。

| Cell | 内容 | 見るところ |
|---|---|---|
| 1 | Drive の `model/` を棚卸し（ネットワークに触らない） | `.pt` の本数と合計 GiB、`ema_best` の実ファイル名 |
| 2 | 載せる重みを決める（既定は EMA-best のみ） | 本数と合計。`best`(raw)・`last` が除外されていること |
| 3 | push 済みリポジトリを clone して v0.3.0 のソース zip を作る | 15–25 が公開側にあるか（無ければ assert で止まる） |
| 4 | Zenodo トークンを入れて今の record を見る | `conceptdoi` が **21217614** であること |
| 5 | 新しい版の下書きを作る | draft id と、引き継いだファイル |
| 6 | 古い source zip を外して、v0.3.0 のソースと重みを上げる | 各ファイルのサイズ照合。最後に名前とサイズが全一致 |
| 7 | メタデータを合わせて下書きの URL を出す（**ここで止まる**） | version v0.3.0、velocity-free 無し、related に AMBER と 10.31223/X5121S |

### トークンの取り方

1. `https://zenodo.org/account/settings/applications/tokens/new/`
2. Name は任意（例 `moirai-l3 upload`）
3. Scopes に **`deposit:write`** と **`deposit:actions`** の両方
4. Create → トークンをコピー（**一度しか表示されない**）

`getpass` で受け取るので画面に出ず、ノートにも残らない。チャットには貼らないこと。

### 既定で載る重み

2026-07-06 に決めた方針と同じ、**EMA-best のみ 44 本**:

| 内訳 | 本数 |
|---|---|
| 正準 LOSO（8 サイト × array/per-trace） | 16 |
| シード（4 サイト × 3 seed × 2 手法、Fig. 4） | 24 |
| station-shuffle 対照（4 サイト） | 4 |

1 本 32 MiB 前後、合計 **約 1.4 GiB** の見込み（Zenodo の容量上限より十分小さい）。
`best`(raw)・`last`・optimizer 状態は結果の再現に不要なので載せない。
Cell 1 の一覧を見て拾い漏れがあれば、Cell 2 の `PATTERN` を実名に合わせて直す。

### Publish は自分で

Cell 7 は下書きの URL を出して止まる。開いて次を確認してから Publish を押す。

- [ ] Version が **v0.3.0**
- [ ] 題名に `velocity-free` が無い
- [ ] ファイルに `moirai-l3-v0.3.0.zip` と `.pt` が並んでいる
- [ ] Related identifiers に AMBER（10.5281/zenodo.18944111）と
      プレプリント（10.31223/X5121S）
- [ ] License が MIT

**公開すると取り消せない。** やり直したいときは下書きを Discard すれば何も公開されない。

### 公開後に確認すること

- [ ] `https://doi.org/10.5281/zenodo.21217614` が **v0.3.0** の record に飛ぶ
- [ ] その record のファイル一覧に **`.pt` が並んでいる**（これが今回の主目的）
- [ ] 同じ record に `moirai-l3-v0.3.0.zip` があり、中に `src/15_*.py` … `src/25_*.py`
- [ ] `https://github.com/ISAO9/moirai-l3` の README に 21217614 と 10.31223/X5121S
- [ ] GitHub にタグ `v0.3.0` がある（Release ページは無くてよい）
- [ ] 使い終わったトークン（GitHub と Zenodo の両方）を Revoke した

## 8. 本文側との整合（投稿前の最終確認）

| 本文の記述 | 対応 |
|---|---|
| concept DOI 10.5281/zenodo.21217614 | 変更なし。README を本文に合わせた |
| GitHub https://github.com/ISAO9/moirai-l3 | 変更なし |
| "The first revision round added scripts 10-14 and their outputs" | v0.2.0 で公開済み |
| "This round adds scripts 15-25 and their outputs" | 本手順で v0.3.0 として公開 |
| "**the EMA-best model weights** ... are released in a public archive" | 節 7 で重み 44 本を同じ record に載せる。**これまで未公開だった** |
| "The figures in this paper are regenerable from the released result logs without retraining" | Colab の Cell 6–7（`25_build_supplement.py --build` が 90/90）が実証 |

> 一点だけ注意。script 20（within-array experiment）は**新しい学習を回す**ので、
> 「without retraining」の対象外。本文は図の再生成についてそう言っているだけで、
> 20 のログ自体はアーカイブに入るため矛盾しない。
